// =============================================================================
// Module: ahbapbbridge
// Purpose: AMBA 3 AHB-Lite to APB 3 Bridge
// Reference: cvw/1tops_soc/src/uncore/ahbapbbridge.sv (David_Harris@hmc.edu & Nic Lucio)
// =============================================================================

module ahbapbbridge #(
    parameter XLEN    = 32,
    parameter PERIPHS = 4
)(
    input                       HCLK,
    input                       HRESETn,
    input      [PERIPHS-1:0]    HSEL,
    input      [31:0]           HADDR,
    input      [XLEN-1:0]       HWDATA,
    input      [XLEN/8-1:0]     HWSTRB,
    input                       HWRITE,
    input      [ 1:0]           HTRANS,
    input                       HREADY,
    output reg [XLEN-1:0]       HRDATA,
    output                      HRESP,
    output                      HREADYOUT,

    // APB Master Bus
    output                      PCLK,
    output                      PRESETn,
    output reg [PERIPHS-1:0]    PSEL,
    output reg                  PWRITE,
    output reg                  PENABLE,
    output reg [31:0]           PADDR,
    output     [XLEN-1:0]       PWDATA,
    output     [XLEN/8-1:0]     PSTRB,
    input      [PERIPHS-1:0]    PREADY,
    input      [PERIPHS*XLEN-1:0] PRDATA
);

    assign PCLK    = HCLK;
    assign PRESETn = HRESETn;

    wire initTrans    = HTRANS[1] & HREADY;
    wire initTransSel = initTrans & (|HSEL);

    reg initTransSelD;
    reg PREADYOUT;

    // Delay AHB Address phase signals to align with APB setup phase
    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn) begin
            PADDR         <= 32'd0;
            PWRITE        <= 1'b0;
            PSEL          <= {PERIPHS{1'b0}};
            initTransSelD <= 1'b0;
            PENABLE       <= 1'b0;
        end else begin
            if (HREADY) begin
                PADDR  <= HADDR;
                PWRITE <= HWRITE;
                PSEL   <= HSEL & {PERIPHS{initTrans}};
            end
            initTransSelD <= initTransSel;
            PENABLE       <= PENABLE ? ~HREADY : initTransSelD;
        end
    end

    assign PWDATA = HWDATA;
    assign PSTRB  = HWSTRB;

    // Multiplex read data and ready signals from selected APB peripheral
    integer i;
    always @(*) begin
        HRDATA    = {XLEN{1'b0}};
        PREADYOUT = 1'b1;
        for (i = 0; i < PERIPHS; i = i + 1) begin
            if (PSEL[i]) begin
                HRDATA    = PRDATA[i*XLEN +: XLEN];
                PREADYOUT = PREADY[i];
            end
        end
    end

    // Hold HREADYOUT low during setup cycle, release when APB access phase completes
    assign HREADYOUT = PREADYOUT & ~initTransSelD;
    assign HRESP     = 1'b0; // Bridge returns OKAY

endmodule
