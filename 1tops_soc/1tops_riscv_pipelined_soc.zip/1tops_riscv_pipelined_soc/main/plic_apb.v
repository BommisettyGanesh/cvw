// =============================================================================
// Module: plic_apb
// Purpose: Platform-Level Interrupt Controller (PLIC) on APB Bus
// Reference: cvw/1tops_soc/src/uncore/plic_apb.sv
// =============================================================================

module plic_apb #(
    parameter XLEN = 32
)(
    input             PCLK,
    input             PRESETn,
    input             PSEL,
    input      [27:0] PADDR,
    input      [31:0] PWDATA,
    input      [ 3:0] PSTRB,
    input             PWRITE,
    input             PENABLE,
    output reg [31:0] PRDATA,
    output            PREADY,
    input             UARTIntr,
    input             GPIOIntr,
    output reg        MExtInt
);

    // Register Offsets
    localparam PLIC_PRIORITY_SRC1 = 24'h000004; // Priority for Source 1 (UART)
    localparam PLIC_PRIORITY_SRC2 = 24'h000008; // Priority for Source 2 (GPIO)
    localparam PLIC_PENDING       = 24'h001000;
    localparam PLIC_ENABLE        = 24'h002000;
    localparam PLIC_THRESHOLD     = 24'h200000;
    localparam PLIC_CLAIM         = 24'h200004;

    reg [2:0] priority_src1;
    reg [2:0] priority_src2;
    reg [2:0] threshold;
    reg [2:0] enables; // bit 1: UART, bit 2: GPIO

    wire memwrite = PWRITE & PENABLE & PSEL;
    assign PREADY = 1'b1;

    wire [2:0] pending = {GPIOIntr, UARTIntr, 1'b0};

    // Calculate maximum priority pending enabled interrupt
    wire src1_active = pending[1] & enables[1] & (priority_src1 > threshold);
    wire src2_active = pending[2] & enables[2] & (priority_src2 > threshold);

    wire [1:0] claim_id = (src2_active && (priority_src2 > priority_src1)) ? 2'd2 :
                          (src1_active) ? 2'd1 :
                          (src2_active) ? 2'd2 : 2'd0;

    // Interrupt output to CPU
    always @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            MExtInt <= 1'b0;
        end else begin
            MExtInt <= (claim_id != 2'd0);
        end
    end

    // APB Read
    always @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            PRDATA <= 32'd0;
        end else begin
            case (PADDR[23:0])
                PLIC_PRIORITY_SRC1: PRDATA <= {29'b0, priority_src1};
                PLIC_PRIORITY_SRC2: PRDATA <= {29'b0, priority_src2};
                PLIC_PENDING:       PRDATA <= {29'b0, pending};
                PLIC_ENABLE:        PRDATA <= {29'b0, enables};
                PLIC_THRESHOLD:     PRDATA <= {29'b0, threshold};
                PLIC_CLAIM:         PRDATA <= {30'b0, claim_id};
                default:            PRDATA <= 32'd0;
            endcase
        end
    end

    // APB Write
    always @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            priority_src1 <= 3'd1;
            priority_src2 <= 3'd1;
            threshold     <= 3'd0;
            enables       <= 3'd0;
        end else if (memwrite) begin
            case (PADDR[23:0])
                PLIC_PRIORITY_SRC1: priority_src1 <= PWDATA[2:0];
                PLIC_PRIORITY_SRC2: priority_src2 <= PWDATA[2:0];
                PLIC_ENABLE:        enables       <= PWDATA[2:0];
                PLIC_THRESHOLD:     threshold     <= PWDATA[2:0];
                default: ;
            endcase
        end
    end

endmodule
