// =============================================================================
// Module: clint_apb
// Purpose: Core-Local Interruptor (CLINT) on APB Bus
// Reference: cvw/1tops_soc/src/uncore/clint_apb.sv (David_Harris@hmc.edu)
// =============================================================================

module clint_apb #(
    parameter XLEN = 32
)(
    input             PCLK,
    input             PRESETn,
    input             PSEL,
    input      [15:0] PADDR,
    input      [31:0] PWDATA,
    input      [ 3:0] PSTRB,
    input             PWRITE,
    input             PENABLE,
    output reg [31:0] PRDATA,
    output            PREADY,
    output reg [63:0] MTIME,
    output            MTimerInt,
    output            MSwInt
);

    // Register Offsets (word-aligned)
    localparam CLINT_MSIP      = 16'h0000;
    localparam CLINT_MTIMECMP  = 16'h4000;
    localparam CLINT_MTIMECMPH = 16'h4004;
    localparam CLINT_MTIME     = 16'hBFF8;
    localparam CLINT_MTIMEH    = 16'hBFFC;

    reg        MSIP;
    reg [63:0] MTIMECMP;

    wire [15:0] entry = {PADDR[15:2], 2'b00};
    wire        memwrite = PWRITE & PENABLE & PSEL;

    assign PREADY    = 1'b1; // CLINT responds with zero wait states
    assign MTimerInt = (MTIME >= MTIMECMP);
    assign MSwInt    = MSIP;

    // APB Read
    always @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            PRDATA <= 32'd0;
        end else begin
            case (entry)
                CLINT_MSIP:      PRDATA <= {31'b0, MSIP};
                CLINT_MTIMECMP:  PRDATA <= MTIMECMP[31:0];
                CLINT_MTIMECMPH: PRDATA <= MTIMECMP[63:32];
                CLINT_MTIME:     PRDATA <= MTIME[31:0];
                CLINT_MTIMEH:    PRDATA <= MTIME[63:32];
                default:         PRDATA <= 32'd0;
            endcase
        end
    end

    // APB Write & Counter Progression
    always @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            MSIP     <= 1'b0;
            MTIMECMP <= 64'hFFFF_FFFF_FFFF_FFFF;
            MTIME    <= 64'd0;
        end else begin
            // MTIME increments every clock cycle unless overwritten
            if (memwrite && (entry == CLINT_MTIME)) begin
                if (PSTRB[0]) MTIME[ 7: 0] <= PWDATA[ 7: 0];
                if (PSTRB[1]) MTIME[15: 8] <= PWDATA[15: 8];
                if (PSTRB[2]) MTIME[23:16] <= PWDATA[23:16];
                if (PSTRB[3]) MTIME[31:24] <= PWDATA[31:24];
            end else if (memwrite && (entry == CLINT_MTIMEH)) begin
                if (PSTRB[0]) MTIME[39:32] <= PWDATA[ 7: 0];
                if (PSTRB[1]) MTIME[47:40] <= PWDATA[15: 8];
                if (PSTRB[2]) MTIME[55:48] <= PWDATA[23:16];
                if (PSTRB[3]) MTIME[63:56] <= PWDATA[31:24];
            end else begin
                MTIME <= MTIME + 64'd1;
            end

            // MSIP write
            if (memwrite && (entry == CLINT_MSIP)) begin
                MSIP <= PWDATA[0];
            end

            // MTIMECMP write
            if (memwrite && (entry == CLINT_MTIMECMP)) begin
                if (PSTRB[0]) MTIMECMP[ 7: 0] <= PWDATA[ 7: 0];
                if (PSTRB[1]) MTIMECMP[15: 8] <= PWDATA[15: 8];
                if (PSTRB[2]) MTIMECMP[23:16] <= PWDATA[23:16];
                if (PSTRB[3]) MTIMECMP[31:24] <= PWDATA[31:24];
            end else if (memwrite && (entry == CLINT_MTIMECMPH)) begin
                if (PSTRB[0]) MTIMECMP[39:32] <= PWDATA[ 7: 0];
                if (PSTRB[1]) MTIMECMP[47:40] <= PWDATA[15: 8];
                if (PSTRB[2]) MTIMECMP[55:48] <= PWDATA[23:16];
                if (PSTRB[3]) MTIMECMP[63:56] <= PWDATA[31:24];
            end
        end
    end

endmodule
