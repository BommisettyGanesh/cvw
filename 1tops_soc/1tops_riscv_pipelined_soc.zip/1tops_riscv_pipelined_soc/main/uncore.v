// =============================================================================
// Module: uncore
// Purpose: System-on-Chip Components Outside the Processor Core
//          Encapsulates:
//            - AHB On-Chip Instruction RAM (ram_i: 0x8000_0000)
//            - AHB On-Chip Data RAM (ram_d: 0x8000_2000)
//            - External AHB Slave / Accelerator Interface (0x3000_0000)
//            - AHB-to-APB Bridge & APB Peripherals (CLINT, PLIC, 16550 UART, GPIO)
// Reference: cvw/1tops_soc/src/uncore/uncore.sv (David_Harris@hmc.edu)
// =============================================================================

module uncore #(
    parameter MEM_SIZE_BYTES  = 16384,
    parameter IRAM_BASE       = 32'h8000_0000,
    parameter IRAM_SIZE_BYTES = MEM_SIZE_BYTES / 2,
    parameter DRAM_BASE       = IRAM_BASE + (MEM_SIZE_BYTES / 2),
    parameter DRAM_SIZE_BYTES = MEM_SIZE_BYTES / 2,
    parameter XLEN            = 32
)(
    input             HCLK,
    input             HRESETn,

    // AHB Bus Master Interface (connected to CPU Core)
    input      [31:0] HADDR,
    input      [31:0] HWDATA,
    input      [ 3:0] HWSTRB,
    input             HWRITE,
    input      [ 2:0] HSIZE,
    input      [ 2:0] HBURST,
    input      [ 3:0] HPROT,
    input      [ 1:0] HTRANS,
    input             HMASTLOCK,
    input             HREADY,
    output     [31:0] HRDATA,
    output            HREADYOUT,
    output            HRESP,

    // External AHB Slave / Accelerator Interface (EXT_MEM: 0x3000_0000 - 0x30FF_FFFF)
    output            HSELEXT,
    input      [31:0] HRDATAEXT,
    input             HREADYEXT,
    input             HRESPEXT,

    // Interrupt & Timer Signals to Core
    output            MTimerInt,
    output            MSwInt,
    output            MExtInt,
    output     [63:0] MTIME_CLINT,

    // Peripheral I/O Pins
    input      [31:0] GPIOIN,
    output     [31:0] GPIOOUT,
    output     [31:0] GPIOEN,
    input             UARTSin,
    output            UARTSout
);

    // =========================================================================
    // 1. AHB Address Decoding (Matching Wally 1tops_soc config.vh & adrdecs.sv)
    // =========================================================================
    // Wally 1tops_soc Memory Map:
    //   - Boot ROM:      0x0000_1000 - 0x0000_1FFF (BOOTROM_BASE)
    //   - CLINT:         0x0200_0000 - 0x0200_FFFF (CLINT_BASE, APB)
    //   - SDC / Debug:   0x0A00_0000 - 0x0A00_0FFF (SDC_BASE, APB)
    //   - PLIC:          0x0C00_0000 - 0x0FFF_FFFF (PLIC_BASE, APB)
    //   - UART:          0x1000_0000 - 0x1000_0FFF (UART_BASE, APB)
    //   - SPI:           0x1004_0000 - 0x1004_0FFF (SPI_BASE, APB)
    //   - GPIO:          0x1006_0000 - 0x1006_0FFF (GPIO_BASE, APB)
    //   - Ext AHB / Acc: 0x3000_0000 - 0x30FF_FFFF (EXT_MEM_BASE, AHB Slave)
    //   - I-RAM (ram_i): 0x8000_0000 - (IRAM_BASE + IRAM_SIZE - 1)
    //   - D-RAM (ram_d): DRAM_BASE   - (DRAM_BASE + DRAM_SIZE - 1)
    wire HSELRam_I   = (HADDR >= IRAM_BASE && HADDR < (IRAM_BASE + IRAM_SIZE_BYTES));
    wire HSELRam_D   = (HADDR >= DRAM_BASE && HADDR < (DRAM_BASE + DRAM_SIZE_BYTES));
    wire HSELEXT_int = (HADDR >= 32'h3000_0000 && HADDR <= 32'h30FF_FFFF);
    wire HSELCLINT   = (HADDR >= 32'h0200_0000 && HADDR <= 32'h0200_FFFF);
    wire HSELPLIC    = (HADDR >= 32'h0C00_0000 && HADDR <= 32'h0FFF_FFFF);
    wire HSELUART    = (HADDR >= 32'h1000_0000 && HADDR <= 32'h1000_0FFF);
    wire HSELGPIO    = (HADDR >= 32'h1006_0000 && HADDR <= 32'h1006_0FFF);

    assign HSELEXT = HSELEXT_int;

    wire [3:0] HSEL_APB = {HSELGPIO, HSELUART, HSELPLIC, HSELCLINT};
    wire       HSELBRIDGE = |HSEL_APB;

    // =========================================================================
    // 2. Address Decoder Delay Registers for AHB Data Phase
    // =========================================================================
    reg HSELRam_ID, HSELRam_DD, HSELEXTD, HSELBRIDGED, HSELNoneD;
    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn) begin
            HSELRam_ID  <= 1'b0;
            HSELRam_DD  <= 1'b0;
            HSELEXTD    <= 1'b0;
            HSELBRIDGED <= 1'b0;
            HSELNoneD   <= 1'b1;
        end else if (HREADY) begin
            HSELRam_ID  <= HSELRam_I;
            HSELRam_DD  <= HSELRam_D;
            HSELEXTD    <= HSELEXT_int;
            HSELBRIDGED <= HSELBRIDGE;
            HSELNoneD   <= !(HSELRam_I | HSELRam_D | HSELEXT_int | HSELBRIDGE);
        end
    end

    // =========================================================================
    // 3. AHB On-Chip Instruction RAM Slave (ram_i: Wally cvw uncore.sv)
    // =========================================================================
    wire [31:0] HRDATA_RAM_I;
    wire        HREADYOUT_RAM_I, HRESP_RAM_I;

    ahb_ram #(
        .BASE_ADDR(IRAM_BASE),
        .MEM_SIZE_BYTES(IRAM_SIZE_BYTES),
        .DEFAULT_WAIT_STATES(0)
    ) ram_i (
        .HCLK(HCLK),
        .HRESETn(HRESETn),
        .HSEL(HSELRam_I),
        .HADDR(HADDR),
        .HTRANS(HTRANS),
        .HWRITE(HWRITE),
        .HSIZE(HSIZE),
        .HWDATA(HWDATA),
        .HWSTRB(HWSTRB),
        .HREADY(HREADY),
        .HRDATA(HRDATA_RAM_I),
        .HREADYOUT(HREADYOUT_RAM_I),
        .HRESP(HRESP_RAM_I)
    );

    // =========================================================================
    // 4. AHB On-Chip Data RAM Slave (ram_d: Wally cvw uncore.sv)
    // =========================================================================
    wire [31:0] HRDATA_RAM_D;
    wire        HREADYOUT_RAM_D, HRESP_RAM_D;

    ahb_ram #(
        .BASE_ADDR(DRAM_BASE),
        .MEM_SIZE_BYTES(DRAM_SIZE_BYTES),
        .DEFAULT_WAIT_STATES(0)
    ) ram_d (
        .HCLK(HCLK),
        .HRESETn(HRESETn),
        .HSEL(HSELRam_D),
        .HADDR(HADDR),
        .HTRANS(HTRANS),
        .HWRITE(HWRITE),
        .HSIZE(HSIZE),
        .HWDATA(HWDATA),
        .HWSTRB(HWSTRB),
        .HREADY(HREADY),
        .HRDATA(HRDATA_RAM_D),
        .HREADYOUT(HREADYOUT_RAM_D),
        .HRESP(HRESP_RAM_D)
    );

    // =========================================================================
    // 5. AHB to APB Bridge
    // =========================================================================
    wire [31:0] HRDATA_BRIDGE;
    wire        HREADYOUT_BRIDGE, HRESP_BRIDGE;

    wire        PCLK, PRESETn;
    wire [ 3:0] PSEL;
    wire        PWRITE, PENABLE;
    wire [31:0] PADDR, PWDATA;
    wire [ 3:0] PSTRB;
    wire [ 3:0] PREADY_PERIPHS;
    wire [127:0] PRDATA_PERIPHS;

    ahbapbbridge #(
        .XLEN(XLEN),
        .PERIPHS(4)
    ) bridge (
        .HCLK(HCLK),
        .HRESETn(HRESETn),
        .HSEL(HSEL_APB),
        .HADDR(HADDR),
        .HWDATA(HWDATA),
        .HWSTRB(HWSTRB),
        .HWRITE(HWRITE),
        .HTRANS(HTRANS),
        .HREADY(HREADY),
        .HRDATA(HRDATA_BRIDGE),
        .HRESP(HRESP_BRIDGE),
        .HREADYOUT(HREADYOUT_BRIDGE),
        .PCLK(PCLK),
        .PRESETn(PRESETn),
        .PSEL(PSEL),
        .PWRITE(PWRITE),
        .PENABLE(PENABLE),
        .PADDR(PADDR),
        .PWDATA(PWDATA),
        .PSTRB(PSTRB),
        .PREADY(PREADY_PERIPHS),
        .PRDATA(PRDATA_PERIPHS)
    );

    // =========================================================================
    // 6. APB Peripherals (CLINT, PLIC, UART, GPIO)
    // =========================================================================
    wire [31:0] PRDATA_CLINT, PRDATA_PLIC, PRDATA_UART, PRDATA_GPIO;
    wire        PREADY_CLINT, PREADY_PLIC, PREADY_UART, PREADY_GPIO;
    wire        UARTIntr, GPIOIntr;

    // Peripheral 0: CLINT (Base: 0x0200_0000)
    clint_apb #(XLEN) clint (
        .PCLK(PCLK),
        .PRESETn(PRESETn),
        .PSEL(PSEL[0]),
        .PADDR(PADDR[15:0]),
        .PWDATA(PWDATA),
        .PSTRB(PSTRB),
        .PWRITE(PWRITE),
        .PENABLE(PENABLE),
        .PRDATA(PRDATA_CLINT),
        .PREADY(PREADY_CLINT),
        .MTIME(MTIME_CLINT),
        .MTimerInt(MTimerInt),
        .MSwInt(MSwInt)
    );

    // Peripheral 1: PLIC (Base: 0x0C00_0000)
    plic_apb #(XLEN) plic (
        .PCLK(PCLK),
        .PRESETn(PRESETn),
        .PSEL(PSEL[1]),
        .PADDR(PADDR[27:0]),
        .PWDATA(PWDATA),
        .PSTRB(PSTRB),
        .PWRITE(PWRITE),
        .PENABLE(PENABLE),
        .PRDATA(PRDATA_PLIC),
        .PREADY(PREADY_PLIC),
        .UARTIntr(UARTIntr),
        .GPIOIntr(GPIOIntr),
        .MExtInt(MExtInt)
    );

    // Peripheral 2: 16550 UART (Base: 0x1000_0000)
    uart_apb #(XLEN) uart (
        .PCLK(PCLK),
        .PRESETn(PRESETn),
        .PSEL(PSEL[2]),
        .PADDR(PADDR[2:0]),
        .PWDATA(PWDATA),
        .PSTRB(PSTRB),
        .PWRITE(PWRITE),
        .PENABLE(PENABLE),
        .PRDATA(PRDATA_UART),
        .PREADY(PREADY_UART),
        .SIN(UARTSin),
        .SOUT(UARTSout),
        .INTR(UARTIntr)
    );

    // Peripheral 3: GPIO (Base: 0x1006_0000)
    gpio_apb #(XLEN) gpio (
        .PCLK(PCLK),
        .PRESETn(PRESETn),
        .PSEL(PSEL[3]),
        .PADDR(PADDR[7:0]),
        .PWDATA(PWDATA),
        .PSTRB(PSTRB),
        .PWRITE(PWRITE),
        .PENABLE(PENABLE),
        .PRDATA(PRDATA_GPIO),
        .PREADY(PREADY_GPIO),
        .GPIOIN(GPIOIN),
        .GPIOOUT(GPIOOUT),
        .GPIOEN(GPIOEN),
        .GPIOIntr(GPIOIntr)
    );

    // Pack APB Peripheral responses into bus arrays
    assign PREADY_PERIPHS = {PREADY_GPIO, PREADY_UART, PREADY_PLIC, PREADY_CLINT};
    assign PRDATA_PERIPHS = {PRDATA_GPIO, PRDATA_UART, PRDATA_PLIC, PRDATA_CLINT};

    // =========================================================================
    // 7. AHB Read Multiplexer & Response Logic (Matching Wally uncore.sv)
    // =========================================================================
    assign HRDATA = HSELRam_ID  ? HRDATA_RAM_I  :
                    HSELRam_DD  ? HRDATA_RAM_D  :
                    HSELEXTD    ? HRDATAEXT     :
                    HSELBRIDGED ? HRDATA_BRIDGE : 32'd0;

    assign HREADYOUT = HSELRam_ID  ? HREADYOUT_RAM_I  :
                       HSELRam_DD  ? HREADYOUT_RAM_D  :
                       HSELEXTD    ? HREADYEXT        :
                       HSELBRIDGED ? HREADYOUT_BRIDGE :
                       HSELNoneD   ? 1'b1 : 1'b1;

    assign HRESP = HSELRam_ID  ? HRESP_RAM_I  :
                   HSELRam_DD  ? HRESP_RAM_D  :
                   HSELEXTD    ? HRESPEXT     :
                   HSELBRIDGED ? HRESP_BRIDGE : 1'b0;

endmodule
