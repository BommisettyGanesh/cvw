// =============================================================================
// Module: ahb_uart
// Purpose: AMBA 3 AHB-Lite UART Interface with Simulation Console Output
//          Compatible with Standard 16550 UART Registers:
//            - Offset 0x0: THR (Transmit Holding Register, Write)
//            - Offset 0x5: LSR (Line Status Register, Read: returns 0x60 for Ready)
// =============================================================================

module ahb_uart (
    input             HCLK,
    input             HRESETn,
    input             HSEL,
    input      [31:0] HADDR,
    input      [ 1:0] HTRANS,
    input             HWRITE,
    input      [ 2:0] HSIZE,
    input      [31:0] HWDATA,
    input      [ 3:0] HWSTRB,
    input             HREADY,
    output reg [31:0] HRDATA,
    output            HREADYOUT,
    output            HRESP,
    output reg        tx_valid,
    output reg [ 7:0] tx_data
);

    assign HREADYOUT = 1'b1;
    assign HRESP     = 1'b0; // OKAY

    wire is_active = HSEL && HREADY && (HTRANS == 2'b10 || HTRANS == 2'b11);

    reg [3:0] addr_reg;
    reg       write_reg;
    reg [3:0] wstrb_reg;
    reg [31:0] hwdata_reg;

    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn) begin
            addr_reg   <= 4'd0;
            write_reg  <= 1'b0;
            wstrb_reg  <= 4'd0;
            hwdata_reg <= 32'd0;
        end else if (HREADY) begin
            addr_reg   <= HADDR[3:0];
            write_reg  <= is_active && HWRITE;
            wstrb_reg  <= HWSTRB;
            hwdata_reg <= HWDATA;
        end
    end

    wire [7:0] byte_written = wstrb_reg[0] ? HWDATA[ 7: 0] :
                              wstrb_reg[1] ? HWDATA[15: 8] :
                              wstrb_reg[2] ? HWDATA[23:16] : HWDATA[31:24];

    // Transmit monitor (Simulation Output)
    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn) begin
            tx_valid <= 1'b0;
            tx_data  <= 8'd0;
        end else begin
            if (write_reg && (addr_reg[3:2] == 2'b00) && (wstrb_reg != 4'b0000)) begin
                tx_valid <= 1'b1;
                tx_data  <= byte_written;
                $write("%c", byte_written);
                $fflush();
            end else begin
                tx_valid <= 1'b0;
            end
        end
    end

    // Line Status Register (LSR) read: return 0x60 (THRE | TEMT = Ready to Transmit)
    always @(posedge HCLK or negedge HRESETn) begin
        if (!HRESETn) begin
            HRDATA <= 32'd0;
        end else if (HREADY && is_active && !HWRITE) begin
            // Replicate 0x60 across all byte lanes so any byte read gets 0x60
            HRDATA <= 32'h6060_6060;
        end
    end

endmodule
