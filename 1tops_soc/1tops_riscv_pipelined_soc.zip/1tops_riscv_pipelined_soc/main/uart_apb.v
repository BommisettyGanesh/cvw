// =============================================================================
// Module: uart_apb
// Purpose: APB Interface to 16550-compatible UART with Simulation Console Stream
// Reference: cvw/1tops_soc/src/uncore/uart_apb.sv & uartPC16550D.sv
// =============================================================================

module uart_apb #(
    parameter XLEN = 32
)(
    input             PCLK,
    input             PRESETn,
    input             PSEL,
    input      [ 2:0] PADDR,
    input      [31:0] PWDATA,
    input      [ 3:0] PSTRB,
    input             PWRITE,
    input             PENABLE,
    output reg [31:0] PRDATA,
    output            PREADY,
    input             SIN,
    output reg        SOUT,
    output            INTR
);

    // 16550 Register Addresses
    localparam UART_RBR_THR_DLL = 3'b000;
    localparam UART_IER_DLM     = 3'b001;
    localparam UART_IIR_FCR     = 3'b010;
    localparam UART_LCR         = 3'b011;
    localparam UART_MCR         = 3'b100;
    localparam UART_LSR         = 3'b101;
    localparam UART_MSR         = 3'b110;
    localparam UART_SCR         = 3'b111;

    reg [7:0] dll, dlm;
    reg [7:0] ier;
    reg [7:0] lcr;
    reg [7:0] mcr;
    reg [7:0] scr;

    wire memwrite = PWRITE & PENABLE & PSEL;
    assign PREADY = 1'b1;

    wire [7:0] din = PWDATA[7:0];
    reg  [7:0] dout;

    // Line Status Register: THRE (bit 5) = 1, TEMT (bit 6) = 1 (Ready to Transmit)
    wire [7:0] lsr = 8'h60;

    // Interrupt line: triggers if transmitter empty interrupt is enabled
    assign INTR = ier[1] & lsr[5];

    // Read Multiplexer
    always @(*) begin
        case (PADDR)
            UART_RBR_THR_DLL: dout = (lcr[7]) ? dll : 8'd0;
            UART_IER_DLM:     dout = (lcr[7]) ? dlm : ier;
            UART_IIR_FCR:     dout = 8'h01; // No interrupt pending
            UART_LCR:         dout = lcr;
            UART_MCR:         dout = mcr;
            UART_LSR:         dout = lsr;
            UART_MSR:         dout = 8'h00;
            UART_SCR:         dout = scr;
            default:          dout = 8'd0;
        endcase
    end

    // Replicate byte across all 4 byte lanes of 32-bit PRDATA
    always @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            PRDATA <= 32'd0;
        end else begin
            PRDATA <= {4{dout}};
        end
    end

    // Write Registers & Simulation Console Output
    always @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            dll  <= 8'd0;
            dlm  <= 8'd0;
            ier  <= 8'd0;
            lcr  <= 8'h03; // 8-bit word length
            mcr  <= 8'd0;
            scr  <= 8'd0;
            SOUT <= 1'b1;
        end else if (memwrite) begin
            case (PADDR)
                UART_RBR_THR_DLL: begin
                    if (lcr[7]) begin
                        dll <= din;
                    end else begin
                        // Transmit Holding Register written: output char in simulation
                        SOUT <= din[0];
`ifndef SYNTHESIS
                        // synthesis translate_off
                        $write("%c", din);
                        $fflush();
                        // synthesis translate_on
`endif
                    end
                end
                UART_IER_DLM: begin
                    if (lcr[7]) dlm <= din;
                    else        ier <= din;
                end
                UART_LCR: lcr <= din;
                UART_MCR: mcr <= din;
                UART_SCR: scr <= din;
                default: ;
            endcase
        end
    end

endmodule
