`timescale 1ns/1ps

module tb_arch_test;

    reg clk;
    reg reset;

    wire        TrapM;
    wire        mretM;
    wire [31:0] PCW, Result;

    // 2 MB memory space (0x80000000 to 0x801FFFFF) for full arch test suite support
    // Split into 1 MB Instruction RAM (ram_i) + 1 MB Data RAM (ram_d)
    localparam MEM_SIZE_BYTES = 2097152;
    localparam MEM_WORDS      = MEM_SIZE_BYTES / 4;
    localparam IRAM_WORDS     = MEM_WORDS / 2;
    localparam DRAM_WORDS     = MEM_WORDS / 2;

    // Temporary storage for binary hex load
    reg [31:0] preload_mem [0:MEM_WORDS-1];

    // Instantiate complete AHB SoC
    riscv_soc_ahb #(
        .RESET_PC(32'h8000_0000),
        .MEM_SIZE_BYTES(MEM_SIZE_BYTES)
    ) dut (
        .clk(clk),
        .reset(reset),
        .MExtInt(1'b0),
        .TrapM(TrapM),
        .mretM(mretM),
        .PCW(PCW),
        .ResultW(Result),
        .GPIOIN(32'd0),
        .GPIOOUT(),
        .GPIOEN(),
        .UARTSin(1'b1),
        .UARTSout(),
        .dbg_sel(1'b0),
        .uart_rx(1'b1),
        .uart_tx(),
        .ft1248_clk(),
        .ft1248_ss_n(),
        .ft1248_miso(1'b1),
        .ft1248_miosio(),
        .core_halted_led()
    );

    // Clock generation (10 ns period)
    always begin
        clk = 1'b0; #5;
        clk = 1'b1; #5;
    end

    // Test parameters
    reg [1023:0] hex_file;
    reg [1023:0] sig_file;
    reg [31:0]   tohost_addr;
    reg [31:0]   begin_sig_addr;
    reg [31:0]   end_sig_addr;
    integer      max_cycles;
    integer      cycles;
    integer      f_sig;
    integer      i;
    reg          halted;

    wire [31:0] tohost_word = (tohost_addr - 32'h80000000) >> 2;

    function [31:0] read_mem_word(input [31:0] byte_addr);
        integer w;
        begin
            w = (byte_addr - 32'h80000000) >> 2;
            if (w < IRAM_WORDS)
                read_mem_word = dut.uncore.ram_i.mem[w];
            else
                read_mem_word = dut.uncore.ram_d.mem[w - IRAM_WORDS];
        end
    endfunction

    initial begin
        clk = 0;
        reset = 1;
        halted = 0;
        cycles = 0;

        // Initialize RAMs to zero
        for (i = 0; i < IRAM_WORDS; i = i + 1) dut.uncore.ram_i.mem[i] = 32'h00000000;
        for (i = 0; i < DRAM_WORDS; i = i + 1) dut.uncore.ram_d.mem[i] = 32'h00000000;
        for (i = 0; i < MEM_WORDS;  i = i + 1) preload_mem[i] = 32'h00000000;

        // Plusargs
        if (!$value$plusargs("HEX=%s", hex_file)) begin
            hex_file = "test.hex";
        end
        if (!$value$plusargs("SIG=%s", sig_file)) begin
            sig_file = "dut.signature";
        end
        if (!$value$plusargs("TOHOST=%x", tohost_addr)) begin
            tohost_addr = 32'h80001000;
        end
        if (!$value$plusargs("BEGIN_SIG=%x", begin_sig_addr)) begin
            begin_sig_addr = 32'h80002000;
        end
        if (!$value$plusargs("END_SIG=%x", end_sig_addr)) begin
            end_sig_addr = 32'h80002100;
        end
        if (!$value$plusargs("MAX_CYCLES=%d", max_cycles)) begin
            max_cycles = 100000;
        end

        $readmemh(hex_file, preload_mem);
        for (i = 0; i < IRAM_WORDS; i = i + 1) begin
            dut.uncore.ram_i.mem[i] = preload_mem[i];
        end
        for (i = 0; i < DRAM_WORDS; i = i + 1) begin
            dut.uncore.ram_d.mem[i] = preload_mem[i + IRAM_WORDS];
        end

        $display("Loaded test: %0s", hex_file);
        $display("tohost=0x%08x, begin_sig=0x%08x, end_sig=0x%08x", tohost_addr, begin_sig_addr, end_sig_addr);

        #50;
        reset = 0;
    end

    // Monitor write to tohost across both IRAM and DRAM
    wire tohost_hit = (dut.uncore.ram_i.write_reg && (tohost_word < IRAM_WORDS) && (dut.uncore.ram_i.wr_addr_reg == tohost_word[17:0])) ||
                      (dut.uncore.ram_d.write_reg && (tohost_word >= IRAM_WORDS) && (dut.uncore.ram_d.wr_addr_reg == (tohost_word[17:0] - IRAM_WORDS[17:0])));

    // Simulation monitor and termination
    always @(posedge clk) begin
        if (!reset) begin
            cycles = cycles + 1;

            if (tohost_hit && !halted) begin
                if (dut.HWDATA == 32'h1 || dut.HWDATA == 32'h3) begin
                    $display("\nWrite to tohost detected at cycle %0d: data = 0x%08x", cycles, dut.HWDATA);
                    halted = 1;
                    // Wait a few cycles for pipeline to settle
                    repeat (10) @(posedge clk);

                    // Dump signature
                    f_sig = $fopen(sig_file, "w");
                    if (f_sig == 0) begin
                        $display("ERROR: Could not open signature file %0s for writing!", sig_file);
                    end else begin
                        for (i = begin_sig_addr; i < end_sig_addr; i = i + 4) begin
                            $fdisplay(f_sig, "%08x", read_mem_word(i));
                        end
                        $fclose(f_sig);
                        $display("Signature successfully written to %0s", sig_file);
                    end
                    $finish;
                end
            end

            if (cycles >= max_cycles) begin
                $display("ERROR: Simulation timed out after %0d cycles! PCM=%h PCF=%h halted=%b tohost_word=%h", 
                         max_cycles, dut.cpu.dp.PCM, dut.cpu.dp.PC, halted, tohost_word);
                $finish;
            end
        end
    end

endmodule
