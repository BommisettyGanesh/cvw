#!/usr/bin/env python3
import sys
import struct

def main():
    if len(sys.argv) < 3:
        print("Usage: bin2hex.py <input.bin> <output.hex>")
        sys.exit(1)
    
    bin_file = sys.argv[1]
    hex_file = sys.argv[2]
    
    with open(bin_file, "rb") as f:
        data = f.read()
    
    # Pad to multiple of 4 bytes
    rem = len(data) % 4
    if rem != 0:
        data += b'\x00' * (4 - rem)
    
    with open(hex_file, "w") as f:
        for i in range(0, len(data), 4):
            word = struct.unpack("<I", data[i:i+4])[0]
            f.write(f"{word:08x}\n")

if __name__ == "__main__":
    main()
