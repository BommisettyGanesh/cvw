
vsim -voptargs=+acc work.tb_arch_test +HEX=work_addi-01/addi-01.hex +SIG=work_addi-01/addi-01.dut.sig +TOHOST=80003000 +BEGIN_SIG=80005104 +END_SIG=800059d0 +MAX_CYCLES=500000 +AHB_WAIT_STATES=1
when {tb_arch_test.dut.cpu.dp.PCM == 32'h800001bc || tb_arch_test.dut.cpu.dp.PCM == 32'h800001c0 || tb_arch_test.dut.cpu.dp.PCM == 32'h800001c4} {
    echo [format "C=%d PCM=%x InstrM=%x ALUResM=%x ResM=%x RdM=%d RegWrM=%b FwdAE=%b SrcAE=%x FwdBE=%b SrcBE=%x" $now $tb_arch_test.dut.cpu.dp.PCM $tb_arch_test.dut.cpu.dp.InstrM $tb_arch_test.dut.cpu.dp.ALUResultM $tb_arch_test.dut.cpu.dp.ResultM $tb_arch_test.dut.cpu.dp.RdM $tb_arch_test.dut.cpu.dp.RegWriteM $tb_arch_test.dut.cpu.dp.ForwardAE $tb_arch_test.dut.cpu.dp.SrcAE $tb_arch_test.dut.cpu.dp.ForwardBE $tb_arch_test.dut.cpu.dp.SrcBE]
}
run 4000ns
quit
