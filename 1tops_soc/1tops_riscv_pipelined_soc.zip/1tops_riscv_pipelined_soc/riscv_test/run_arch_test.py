#!/usr/bin/env python3
import os
import sys
import glob
import json
import re
import struct
import shutil
import subprocess
import argparse

GCC = "riscv64-unknown-elf-gcc"
OBJCOPY = "riscv64-unknown-elf-objcopy"
NM = "riscv64-unknown-elf-nm"
SPIKE = "/home/ganesh/cvw/bin/spike"
SAIL = "/home/ganesh/cvw/bin/sail_riscv_sim"
VSIM = "/home/ganesh/altera_lite/25.1std/questa_fse/bin/vsim"
VLOG = "/home/ganesh/altera_lite/25.1std/questa_fse/bin/vlog"
VLIB = "/home/ganesh/altera_lite/25.1std/questa_fse/bin/vlib"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(SCRIPT_DIR)
SAIL_CONFIG = os.path.join(SCRIPT_DIR, "sail_rv32.json")

# Test Suite Directories
RV32I_SUITE_DIR = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test/riscv-test-suite/rv32i_m/I/src"
ZICSR_SUITE_DIR = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test-cvw/tests/rv32i/Zicsr"
ZICNTR_SUITE_DIR = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test-cvw/tests/rv32i/Zicntr"
PRIVILEGE_SUITE_DIR = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test/riscv-test-suite/rv32i_m/privilege/src"
ZIFENCEI_SUITE_DIR = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test/riscv-test-suite/rv32i_m/Zifencei/src"

# Environments
ENV_DIR = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test/riscv-test-suite/env"
MODEL_ENV_DIR = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test/riscof-plugins/rv32/spike_simple/env"
LINK_LD = "/home/ganesh/Desktop/wally_reference/cvw/tests/riscof/spike/env/link.ld"
ZICSR_ENV_DIR = os.path.join(SCRIPT_DIR, "zicsr_env")
ZICSR_TESTS_ENV = "/home/ganesh/Desktop/wally_reference/cvw/addins/riscv-arch-test-cvw/tests/env"

def run_cmd(cmd, cwd=None):
    res = subprocess.run(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode != 0:
        return False, res.stdout + "\n" + res.stderr
    return True, res.stdout

def ensure_sail_config():
    """Generates a valid 32-bit RV32I+Zicsr+Zicntr+Zifencei configuration for Sail if not present."""
    if os.path.exists(SAIL_CONFIG):
        return True
    try:
        ok, out = run_cmd(f"{SAIL} --print-default-config")
        if not ok:
            print("[SAIL CONFIG ERROR] Failed to query default configuration from Sail.")
            return False
        lines = [re.sub(r"//.*$", "", l) for l in out.splitlines()]
        cfg = json.loads("\n".join(lines))
        cfg["base"]["xlen"] = 32
        if "vector" in cfg:
            cfg["vector"]["supported"] = False
        if "V" in cfg.get("extensions", {}):
            cfg["extensions"]["V"]["support_level"] = "Disabled"
        for ext, val in cfg.get("extensions", {}).items():
            if isinstance(val, dict) and "supported" in val:
                if ext in ["Zicsr", "Zicntr", "Zifencei"]:
                    val["supported"] = True
                else:
                    val["supported"] = False
        with open(SAIL_CONFIG, "w") as f:
            json.dump(cfg, f, indent=2)
        return True
    except Exception as e:
        print(f"[SAIL CONFIG ERROR] Could not generate {SAIL_CONFIG}: {e}")
        return False

def compile_rtl(verbose=False):
    """
    Cleans and freshly recompiles the core RTL and testbench into Questa's 'work' library.
    Guarantees no stale compiled files or cached elaboration objects (_opt) are reused.
    """
    os.chdir(SCRIPT_DIR)
    work_dir = os.path.join(SCRIPT_DIR, "work")
    if os.path.exists(work_dir):
        shutil.rmtree(work_dir, ignore_errors=True)

    ok, out = run_cmd(f"{VLIB} work")
    if not ok:
        print("[RTL COMPILE ERROR] Failed to vlib work:\n" + out)
        return False

    components = sorted(glob.glob(f"{REPO_ROOT}/components/*.v"))
    main_files = [
        f"{REPO_ROOT}/main/ahb_ram.v",
        f"{REPO_ROOT}/main/ahbapbbridge.v",
        f"{REPO_ROOT}/main/clint_apb.v",
        f"{REPO_ROOT}/main/plic_apb.v",
        f"{REPO_ROOT}/main/uart_apb.v",
        f"{REPO_ROOT}/main/gpio_apb.v",
        f"{REPO_ROOT}/main/multiplier_ahb.v",
        f"{REPO_ROOT}/main/uncore.v",
        f"{REPO_ROOT}/main/riscv_cpu.v",
        f"{REPO_ROOT}/main/riscv_soc_ahb.v"
    ]
    debugger_files = sorted(glob.glob(f"{REPO_ROOT}/debugger/*.v") + glob.glob(f"{REPO_ROOT}/debugger/*.sv"))
    tb_file = f"{SCRIPT_DIR}/tb_arch_test.v"

    src_files = components + main_files + debugger_files + [tb_file]
    src_str = " ".join(src_files)

    cmd = (
        f"{VLOG} -sv -timescale 1ns/1ps -work work +incdir+{REPO_ROOT}/main +incdir+{REPO_ROOT}/components +incdir+{REPO_ROOT}/debugger {src_str}"
    )
    ok, out = run_cmd(cmd)
    if not ok:
        print("[RTL COMPILE ERROR] Compilation failed:\n" + out)
        return False
    if verbose:
        print(out)
    return True

def bin_to_hex(bin_path, hex_path):
    with open(bin_path, "rb") as f:
        data = f.read()
    rem = len(data) % 4
    if rem != 0:
        data += b'\x00' * (4 - rem)
    with open(hex_path, "w") as f:
        for i in range(0, len(data), 4):
            word = struct.unpack("<I", data[i:i+4])[0]
            f.write(f"{word:08x}\n")

def get_symbols(elf_path):
    ok, out = run_cmd(f"{NM} {elf_path}")
    if not ok:
        raise RuntimeError("nm failed:\n" + out)
    symbols = {}
    for line in out.strip().splitlines():
        parts = line.split()
        if len(parts) >= 3:
            addr, sym_type, name = parts[0], parts[1], parts[2]
            symbols[name] = int(addr, 16)
    return symbols

def run_single_test(test_path, ref_model="spike", verbose=False, wait_states="0"):
    test_name = os.path.splitext(os.path.basename(test_path))[0]
    test_work = os.path.join(SCRIPT_DIR, "work_" + test_name)
    os.makedirs(test_work, exist_ok=True)

    elf_file = os.path.join(test_work, f"{test_name}.elf")
    bin_file = os.path.join(test_work, f"{test_name}.bin")
    hex_file = os.path.join(test_work, f"{test_name}.hex")
    ref_sig = os.path.join(test_work, f"{test_name}.{ref_model}.sig")
    dut_sig = os.path.join(test_work, f"{test_name}.dut.sig")

    # Clean previous run outputs to prevent stale files or false passes
    for f in [elf_file, bin_file, hex_file, ref_sig, dut_sig]:
        if os.path.exists(f):
            try:
                os.remove(f)
            except OSError:
                pass

    tfile = os.path.basename(test_path)
    lower_path = test_path.lower()
    lower_name = test_name.lower()

    # 1. Compile test with riscv gcc and determine Spike ISA flag
    if "zicntr" in lower_path or "zicntr" in lower_name:
        compile_cmd = (
            f"{GCC} -march=rv32i -mabi=ilp32 -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles "
            f"-T {LINK_LD} -I {ZICSR_ENV_DIR} -I {ZICSR_TESTS_ENV} -DSIGNATURE "
            f"-DSAIL_CLINT_BASE_ADDRESS=0x2000000 -DSAIL_SIMPLE_INTERRUPT_GENERATOR_BASE_ADDRESS=0x3000000 "
            f'-DTEST_FILE=\\"{tfile}\\" -DXLEN=32 '
            f"{test_path} -o {elf_file}"
        )
        spike_isa = "rv32i_zicsr_zicntr"
    elif "zicsr" in lower_path or "zicsr" in lower_name:
        compile_cmd = (
            f"{GCC} -march=rv32i -mabi=ilp32 -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles "
            f"-T {LINK_LD} -I {ZICSR_ENV_DIR} -I {ZICSR_TESTS_ENV} -DSIGNATURE "
            f"-DSAIL_CLINT_BASE_ADDRESS=0x2000000 -DSAIL_SIMPLE_INTERRUPT_GENERATOR_BASE_ADDRESS=0x3000000 "
            f'-DTEST_FILE=\\"{tfile}\\" -DXLEN=32 '
            f"{test_path} -o {elf_file}"
        )
        spike_isa = "rv32i_zicsr"
    elif "privilege" in lower_path or lower_name in ["ecall", "ebreak"]:
        compile_cmd = (
            f"{GCC} -march=rv32i -mabi=ilp32 -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles "
            f"-T {LINK_LD} -I {MODEL_ENV_DIR} -I {ENV_DIR} -DTEST_CASE_1=True -Drvtest_mtrap_routine=True -DXLEN=32 "
            f"{test_path} -o {elf_file}"
        )
        spike_isa = "rv32i_zicsr"
    elif "zifencei" in lower_path or "fencei" in lower_name:
        compile_cmd = (
            f"{GCC} -march=rv32i -mabi=ilp32 -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles "
            f"-T {LINK_LD} -I {MODEL_ENV_DIR} -I {ENV_DIR} -DTEST_CASE_1=True -DXLEN=32 "
            f"{test_path} -o {elf_file}"
        )
        spike_isa = "rv32i_zicsr_zifencei"
    else:  # Base RV32I
        compile_cmd = (
            f"{GCC} -march=rv32i -mabi=ilp32 -static -mcmodel=medany -fvisibility=hidden -nostdlib -nostartfiles "
            f"-T {LINK_LD} -I {MODEL_ENV_DIR} -I {ENV_DIR} -DTEST_CASE_1=True -DXLEN=32 "
            f"{test_path} -o {elf_file}"
        )
        spike_isa = "rv32i"

    ok, out = run_cmd(compile_cmd)
    if not ok:
        return "COMPILE_ERROR", out

    # 2. Run reference golden model (Spike or Sail) to generate reference signature
    if ref_model == "sail":
        ref_cmd = f"{SAIL} --config {SAIL_CONFIG} --test-signature={ref_sig} --signature-granularity=4 {elf_file}"
    else:
        ref_cmd = f"{SPIKE} --isa={spike_isa} +signature={ref_sig} +signature-granularity=4 {elf_file}"

    ok, out = run_cmd(ref_cmd)
    if not ok:
        return f"{ref_model.upper()}_ERROR", out

    # 3. Create flat binary and hex file
    ok, out = run_cmd(f"{OBJCOPY} -O binary {elf_file} {bin_file}")
    if not ok:
        return "OBJCOPY_ERROR", out
    bin_to_hex(bin_file, hex_file)

    # 4. Extract symbols from ELF
    symbols = get_symbols(elf_file)
    tohost_addr = symbols.get("tohost")
    begin_sig_addr = symbols.get("begin_signature")
    end_sig_addr = symbols.get("end_signature")

    if tohost_addr is None or begin_sig_addr is None or end_sig_addr is None:
        return "SYMBOL_ERROR", f"Missing symbols: tohost={tohost_addr}, begin_sig={begin_sig_addr}, end_sig={end_sig_addr}"

    # 5. Run QuestaSim simulation
    wait_arg = ""
    if str(wait_states).lower() == "random":
        wait_arg = "+AHB_WAIT_RANDOM"
    elif str(wait_states).isdigit() and int(wait_states) > 0:
        wait_arg = f"+AHB_WAIT_STATES={wait_states}"

    vsim_cmd = (
        f"{VSIM} -c -voptargs=\"+acc\" -do 'run -all; quit' work.tb_arch_test "
        f"+HEX={hex_file} +SIG={dut_sig} "
        f"+TOHOST={tohost_addr:x} +BEGIN_SIG={begin_sig_addr:x} +END_SIG={end_sig_addr:x} "
        f"+MAX_CYCLES=2000000 {wait_arg}"
    )
    ok, out = run_cmd(vsim_cmd, cwd=SCRIPT_DIR)

    if "ERROR: Simulation timed out" in out or "Simulation timed out" in out:
        return "SIM_TIMEOUT", f"Simulation timed out (write to tohost was never reached)"

    if not ok:
        return "SIM_CRASH", out

    if not os.path.exists(dut_sig):
        return "SIM_NO_SIG", f"DUT signature file was not produced.\nQuesta output:\n{out}"

    # 6. Compare DUT signature with reference signature (Spike or Sail)
    with open(ref_sig, "r") as f:
        ref_lines = f.readlines()
    with open(dut_sig, "r") as f:
        dut_lines = f.readlines()

    if len(ref_lines) == 0:
        return "FAIL", f"{ref_model.capitalize()} signature is empty"
    if len(dut_lines) == 0:
        return "FAIL", "DUT signature is empty"

    if ref_lines != dut_lines:
        diff_count = 0
        diff_detail = []
        max_len = max(len(ref_lines), len(dut_lines))
        for idx in range(max_len):
            r_val = ref_lines[idx].strip() if idx < len(ref_lines) else "<MISSING>"
            d_val = dut_lines[idx].strip() if idx < len(dut_lines) else "<MISSING>"
            if r_val != d_val:
                diff_count += 1
                if len(diff_detail) < 10:
                    diff_detail.append(f"  Word {idx}: {ref_model.capitalize()}={r_val} DUT={d_val}")
        return "MISMATCH", f"{diff_count} signature differences:\n" + "\n".join(diff_detail)

    return "PASS", f"Matched {len(ref_lines)} signature words"

def get_suite_tests(suite_name):
    rv32i_tests = sorted(glob.glob(os.path.join(RV32I_SUITE_DIR, "*.S")))
    zicsr_tests = sorted(glob.glob(os.path.join(ZICSR_SUITE_DIR, "*.S")))
    zicntr_tests = sorted(glob.glob(os.path.join(ZICNTR_SUITE_DIR, "*.S")))
    priv_tests = [
        os.path.join(PRIVILEGE_SUITE_DIR, "ecall.S"),
        os.path.join(PRIVILEGE_SUITE_DIR, "ebreak.S")
    ]
    zifencei_tests = [
        os.path.join(ZIFENCEI_SUITE_DIR, "Fencei.S")
    ]

    if suite_name == "rv32i":
        return rv32i_tests
    elif suite_name == "zicsr":
        return zicsr_tests
    elif suite_name == "zicntr":
        return zicntr_tests
    elif suite_name == "privilege":
        return priv_tests
    elif suite_name == "zifencei":
        return zifencei_tests
    elif suite_name == "all":
        return rv32i_tests + zicsr_tests + zicntr_tests + priv_tests + zifencei_tests
    return []

def find_test(test_name_or_path):
    if os.path.exists(test_name_or_path):
        return test_name_or_path

    all_tests = get_suite_tests("all")
    for t in all_tests:
        basename = os.path.splitext(os.path.basename(t))[0]
        if basename == test_name_or_path or basename == f"{test_name_or_path}-00" or basename == f"Zicsr-{test_name_or_path}-00" or basename == f"Zicntr-{test_name_or_path}-00":
            return t
        if test_name_or_path.lower() in basename.lower():
            return t
    return None

def main():
    parser = argparse.ArgumentParser(description="Run RISC-V arch test with QuestaSim vs Spike/Sail reference model")
    parser.add_argument("--test", type=str, help="Specific test name or path (e.g. addi-01, Zicsr-csrrw-00, csrrw, ecall, ebreak, Fencei)")
    parser.add_argument("--suite", type=str, choices=["rv32i", "zicsr", "zicntr", "privilege", "zifencei", "all"], default="all", help="Suite to run: rv32i, zicsr, zicntr, privilege, zifencei, or all (default: all)")
    parser.add_argument("--model", type=str, choices=["spike", "sail"], default="spike", help="Golden reference model to compare against: spike or sail (default: spike)")
    parser.add_argument("--sail", action="store_true", help="Shortcut to select Sail as the reference model (equivalent to --model sail)")
    parser.add_argument("--spike", action="store_true", help="Shortcut to select Spike as the reference model (equivalent to --model spike)")
    parser.add_argument("--zicsr", action="store_true", help="Shortcut to run Zicsr CSR extension tests")
    parser.add_argument("--all", action="store_true", help="Run all tests across all supported extensions")
    parser.add_argument("--wait-states", default="0", help="AHB wait states to inject: 0 (default), 1, 2, 3, or 'random'")
    args = parser.parse_args()

    ref_model = "sail" if args.sail else ("spike" if args.spike else args.model.lower())

    print(f"=== RISC-V Architecture Test Runner (QuestaSim vs {ref_model.upper()}) ===")
    print(f"[*] Golden Reference Model: {ref_model.upper()}")
    if ref_model == "sail":
        if not ensure_sail_config():
            print("ERROR: Failed to prepare Sail configuration. Aborting.")
            sys.exit(1)

    print("[*] Recompiling core RTL and testbench...")
    if not compile_rtl():
        print("ERROR: RTL compilation failed. Aborting tests.")
        sys.exit(1)
    print("[*] Compilation finished successfully.\n")

    if args.test:
        test_path = find_test(args.test)
        if not test_path or not os.path.exists(test_path):
            print(f"Error: test file not found: {args.test}")
            sys.exit(1)
        tests = [test_path]
    elif args.zicsr:
        tests = get_suite_tests("zicsr")
    else:
        tests = get_suite_tests(args.suite)

    print(f"Running suite: {args.suite if not args.test else 'single-test'} ({len(tests)} test(s))\n")

    results = {}
    for test_path in tests:
        tname = os.path.splitext(os.path.basename(test_path))[0]
        status, detail = run_single_test(test_path, ref_model=ref_model, wait_states=args.wait_states)
        results[tname] = (status, detail)
        symbol = "✓" if status == "PASS" else "✗"
        print(f"[{symbol}] {tname:24s}: {status} - {detail.splitlines()[0] if detail else ''}")

    print("\n" + "=" * 50)
    print("=== Summary ===")
    print("=" * 50)
    passed = sum(1 for s, _ in results.values() if s == "PASS")
    total = len(results)
    print(f"Passed: {passed}/{total}")
    if passed < total:
        print("\nFailures:")
        for tname, (status, detail) in results.items():
            if status != "PASS":
                print(f"  {tname} ({status}):")
                for line in detail.splitlines()[:5]:
                    print(f"    {line}")

    if passed == total:
        print(f"\n🎉 ALL TESTS PASSED SUCCESSFULLY AGAINST {ref_model.upper()} GOLDEN MODEL!")
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()
