transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/ebu.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/ahbinterface.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/subword_unit.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/trap_unit.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/priv_decoder.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/mux5.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/csr_file.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/reset_ff.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/reg_file.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/pl_reg_mw.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/pl_reg_fd.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/pl_reg_em.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/pl_reg_de.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/mux3.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/mux2.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/main_decoder.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/imm_extend.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/hazard.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/datapath.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/controller.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/branching_unit.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/alu_decoder.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/alu.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/components/adder.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/riscv_cpu.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/riscv_soc_ahb.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/ahb_ram.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/ahbapbbridge.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/clint_apb.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/plic_apb.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/uart_apb.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/gpio_apb.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/uncore.v}
vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/main/multiplier_ahb.v}

vlog  -work work +incdir+/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/.test {/home/ganesh/Desktop/riscv/riscv_pipelined_quartus/.test/tb.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  tb

add wave *
view structure
view signals
run -all
