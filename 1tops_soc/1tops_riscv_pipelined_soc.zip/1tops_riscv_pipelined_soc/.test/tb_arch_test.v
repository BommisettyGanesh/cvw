`timescale 1ns/1ps

module tb_arch_test;

    reg clk;
    reg reset;

    wire [31:0] PC;
    wire [31:0] Instr;
    wire        MemWriteM;
    wire [31:0] Mem_WrAddr, Mem_WrData;
    wire [31:0] ReadData;
    wire [31:0] Result;
    wire [ 2:0] funct3;
    wire [31:0] PCW, ALUResultW, WriteDataW;
    wire        TrapM;

    // Simple cycle counter to feed MTIME_CLINT
    reg [63:0]  tb_mtime;
    always @(posedge clk) begin
        if (reset) tb_mtime <= 64'd0;
        else       tb_mtime <= tb_mtime + 64'd1;
    end

    // 512K words = 2 MB memory space (0x80000000 to 0x801FFFFF)
    localparam MEM_WORDS = 524288;
    reg [31:0] ram [0:MEM_WORDS-1];

    // DUT core
    riscv_cpu #(.RESET_PC(32'h8000_0000)) dut (
        .clk(clk),
        .reset(reset),
        .PC(PC),
        .Instr(Instr),
        .MemWriteM(MemWriteM),
        .Mem_WrAddr(Mem_WrAddr),
        .Mem_WrData(Mem_WrData),
        .ReadData(ReadData),
        .Result(Result),
        .funct3(funct3),
        .PCW(PCW),
        .ALUResultW(ALUResultW),
        .WriteDataW(WriteDataW),
        .MTimerInt(1'b0),
        .MSwInt(1'b0),
        .MExtInt(1'b0),
        .MTIME_CLINT(tb_mtime),
        .TrapM(TrapM)
    );

    // Instruction memory interface
    wire [18:0] pc_word = (PC - 32'h80000000) >> 2;
    assign Instr = (PC >= 32'h80000000 && pc_word < MEM_WORDS) ? ram[pc_word] : 32'h00000013; // nop

    // Data memory interface
    wire [18:0] data_word = (Mem_WrAddr - 32'h80000000) >> 2;
    wire [31:0] rd_data_ram = (Mem_WrAddr >= 32'h80000000 && data_word < MEM_WORDS) ? ram[data_word] : 32'h0;
    wire [31:0] wr_data_in;

    data_mem_ip d_in (funct3, Mem_WrAddr[1:0], Mem_WrData, rd_data_ram, wr_data_in);
    data_mem_op d_out (funct3, Mem_WrAddr[1:0], rd_data_ram, ReadData);

    // Memory write
    always @(posedge clk) begin
        if (!reset && MemWriteM && (Mem_WrAddr >= 32'h80000000) && (data_word < MEM_WORDS)) begin
            ram[data_word] <= wr_data_in;
        end
    end

    // Clock generation (10 ns period)
    always begin
        clk = 1'b0; #5;
        clk = 1'b1; #5;
    end

    // Test parameters
    reg [1023:0] hex_file;
    reg [1023:0] sig_file;
    reg [31:0]   tohost_addr;
    reg [31:0]   begin_sig_addr;
    reg [31:0]   end_sig_addr;
    integer      max_cycles;
    integer      cycles;
    integer      f_sig;
    integer      i;
    reg          halted;

    initial begin
        clk = 0;
        reset = 1;
        halted = 0;
        cycles = 0;

        // Initialize RAM to zero
        for (i = 0; i < MEM_WORDS; i = i + 1) begin
            ram[i] = 32'h00000000;
        end

        // Plusargs
        if (!$value$plusargs("HEX=%s", hex_file)) begin
            hex_file = "test.hex";
        end
        if (!$value$plusargs("SIG=%s", sig_file)) begin
            sig_file = "dut.signature";
        end
        if (!$value$plusargs("TOHOST=%x", tohost_addr)) begin
            tohost_addr = 32'h80001000;
        end
        if (!$value$plusargs("BEGIN_SIG=%x", begin_sig_addr)) begin
            begin_sig_addr = 32'h80002000;
        end
        if (!$value$plusargs("END_SIG=%x", end_sig_addr)) begin
            end_sig_addr = 32'h80002100;
        end
        if (!$value$plusargs("MAX_CYCLES=%d", max_cycles)) begin
            max_cycles = 100000;
        end

        $readmemh(hex_file, ram);
        $display("Loaded test: %0s", hex_file);
        $display("tohost=0x%08x, begin_sig=0x%08x, end_sig=0x%08x", tohost_addr, begin_sig_addr, end_sig_addr);

        #50;
        reset = 0;
    end

    // Simulation monitor and termination
    always @(posedge clk) begin
        if (!reset) begin
            cycles = cycles + 1;

            // Check tohost write
            if (MemWriteM && (Mem_WrAddr == tohost_addr) && !halted) begin
                if (Mem_WrData == 32'h1 || Mem_WrData == 32'h3) begin
                    $display("\nWrite to tohost detected at cycle %0d: data = 0x%08x", cycles, Mem_WrData);
                    halted = 1;
                    // Wait a few cycles for pipeline to settle
                    repeat (10) @(posedge clk);

                    // Dump signature
                    f_sig = $fopen(sig_file, "w");
                    if (f_sig == 0) begin
                        $display("ERROR: Could not open signature file %0s for writing!", sig_file);
                    end else begin
                        for (i = begin_sig_addr; i < end_sig_addr; i = i + 4) begin
                            $fdisplay(f_sig, "%08x", ram[(i - 32'h80000000) >> 2]);
                        end
                        $fclose(f_sig);
                        $display("Signature successfully written to %0s", sig_file);
                    end
                    $finish;
                end
            end

            if (cycles >= max_cycles) begin
                $display("ERROR: Simulation timed out after %0d cycles!", max_cycles);
                $finish;
            end
        end
    end

endmodule
