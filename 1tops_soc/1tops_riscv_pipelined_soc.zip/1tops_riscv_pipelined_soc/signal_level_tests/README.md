# Signal-Level Verification Suite for RISC-V Pipelined SoC

This directory contains the **Signal-Level Verification Suite** for the 5-stage pipelined RISC-V SoC with AHB-Lite and APB buses.

## 1. Directory Structure

```
signal_level_tests/
├── Makefile                               # Top-level orchestrator (always recompiles before running)
├── README.md                              # This documentation
├── assertions/                            # Formal SVA protocol checkers and Wally monitors
│   ├── ahb_protocol_checker.sv            # AMBA 3 AHB-Lite protocol checker
│   ├── apb_protocol_checker.sv            # AMBA 3 APB bridge & peripheral protocol checker
│   ├── core_invariants_checker.sv         # 5-stage pipeline signal invariants checker
│   ├── ramxdetector.sv                    # OpenHW CVW uninitialized RAM / X-propagation detector
│   └── watchdog.sv                        # OpenHW CVW hang & recursive trap livelock detector
├── stress_tests/                          # Signal-level assembly test suites
│   ├── hazard_forwarding_stress.S         # EX/MEM forwarding & load-use stall stress
│   ├── branch_collision_stress.S          # Branch shadow flush & loop stress
│   ├── interrupt_trap_stress.S            # CLINT timer interrupt & mret resumption
│   ├── exception_trap_stress.S            # ecall, ebreak, and illegal instruction exceptions
│   ├── subword_access_stress.S            # HWSTRB byte strobes, sign/zero extension
│   ├── apb_bus_stress.S                   # Back-to-back APB read/write without idle bubbles
│   ├── link.ld                            # Linker script placing tohost at 0x8000_1000
│   ├── elf2mem.py                         # ELF binary to Verilog hex converter
│   ├── Makefile                           # Assembler & memory generator
│   └── wally_periph/                      # OpenHW CVW (Wally) peripheral integration tests
│       ├── WALLY-gpio-01.S                # Wally GPIO test suite
│       ├── WALLY-uart-01.S                # Wally UART test suite
│       ├── WALLY-clint-01.S               # Wally CLINT test suite
│       └── WALLY-plic-01.S                # Wally PLIC test suite
├── testbench/                             # Simulation harness
│   ├── tb_signal_level.sv                 # Master SoC testbench with all checkers bound
│   └── Makefile                           # QuestaSim compilation & simulation driver
└── coverage/                              # Coverage outputs (statement, branch, condition, toggle)
    └── coverage_report.txt                # Detailed QuestaSim coverage report
```

## 2. Checkers & Monitors Active During Simulation

All tests run concurrently with 5 hardware assertion checkers bound directly to DUT internals:
1. **`ahb_protocol_checker.sv`**: Checks AHB-Lite wait-state control signal stability (`HADDR`, `HWRITE`, `HSIZE`, `HTRANS`), one-hot slave decode, and absence of `X`/`Z`.
2. **`apb_protocol_checker.sv`**: Checks APB setup-to-access timing, `PENABLE` following `PSEL`, stability across wait states, and one-hot peripheral selection.
3. **`core_invariants_checker.sv`**: Checks PC word alignment (`PC[1:0] == 00`), x0 register immutability, forwarding mux index validity, and trap redirection to `mtvec`.
4. **`ramxdetector.sv`**: Ported from OpenHW CVW to detect uninitialized RAM reads and prevent X-propagation.
5. **`watchdog.sv`**: Ported from OpenHW CVW to detect hung pipelines and recursive trap livelocks.

## 3. How to Run the Tests

Every test target **automatically recompiles the design and testbench from scratch** with `vlog` before simulation:

```bash
cd signal_level_tests

# Run all 10 tests:
make test_all

# Run individual microarchitectural stress tests:
make test_hazards            # Hazard & forwarding stress
make test_branch_collision   # Branch flush stress
make test_interrupts         # CLINT timer interrupt stress
make test_exceptions         # ecall/ebreak/illegal instruction stress
make test_subwords           # Subword access & byte strobes
make test_apb_stress         # Back-to-back APB transfer stress

# Run OpenHW CVW peripheral integration tests:
make test_wally_gpio         # Wally GPIO test
make test_wally_uart         # Wally UART test
make test_wally_clint        # Wally CLINT test
make test_wally_plic         # Wally PLIC test

# Generate code & signal coverage report:
make coverage
```
